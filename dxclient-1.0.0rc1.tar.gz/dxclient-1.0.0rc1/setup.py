from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name="dxclient",
    version="1.0.0rc1",
    author="Sushant Aggarwal",
    author_email="sushant.aggarwal@ihsmarkit.com",
    maintainer="Sushant Aggarwal",
    maintainer_email="sushant.aggarwal@ihsmarkit.com",
    description="DxOpen Client for Python 3.7 onwards. Created by Sushant Aggarwal.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=['generateDS>=2.35.7', 'setuptools>=42.0.2', 'pip>=19.3.1'],
    url="https://ihsmarkit.com/products/securities-finance.html",
    packages=find_packages(include=['dxclient', 'dxclient.Query'], exclude=["Other_Project_Files", "Samples"]),
    python_requires='>=3.7',
    classifiers=(
        "Programming Language :: Python :: 3.7",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    )
)